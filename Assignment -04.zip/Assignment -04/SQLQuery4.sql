
--Check Allotments Table:
SELECT * FROM Allotments;
