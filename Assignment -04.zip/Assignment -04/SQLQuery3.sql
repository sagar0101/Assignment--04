-- Execute the stored procedure to allocate subjects
EXEC AllocateSubjects;
