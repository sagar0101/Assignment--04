--Check UnallotedStudents Table:
SELECT * FROM UnallotedStudents;

